# Data Manipulation libraries
import pandas as pd
from sklearn.model_selection  import train_test_split
from sklearn.linear_model import LinearRegression
import joblib #lightweight pipelining in Python

df = pd.read_csv('data.txt')  # Load the dataset

df_x = df[['area', 'rooms']]
df_y = df[['price']]

from sklearn.preprocessing import StandardScaler
scaler = StandardScaler()

df_x_scaled = scaler.fit_transform(df_x)
df_x_scaled = pd.DataFrame(df_x_scaled, columns=df_x.columns)
print(df_x_scaled.head(), flush=True)

from joblib import dump
dump(scaler, './model/std_scaler.bin', compress=True)

X_train, X_test, Y_train, Y_test = train_test_split(df_x_scaled, df_y, test_size = 0.33, random_state = 5)
print(X_train.head())

lr = LinearRegression()
lr.fit(X_train, Y_train)
Y_predict = lr.predict(X_test)

#Saving the machine learning model to a file
joblib.dump(lr, "./model/model.pkl")
