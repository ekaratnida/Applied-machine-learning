from flask import Flask, jsonify, request, render_template
import pandas as pd
import joblib
from joblib import load
app = Flask(__name__)

@app.route("/predict", methods=['POST'])
def do_prediction():
    json = request.get_json()
    model = joblib.load('model/model.pkl')
    df = pd.DataFrame(json, index=[0])
    print(df.head(), flush=True) #use flush for output text on docker

    from sklearn.preprocessing import StandardScaler
    scaler = StandardScaler()
    scaler = load('model/std_scaler.bin')

    df_x_scaled = scaler.transform(df)
    df_x_scaled = pd.DataFrame(df_x_scaled, columns=df.columns)
    print(df_x_scaled.head(), flush=True)

    y_predict = model.predict(df_x_scaled)
    print(y_predict, flush=True)
    
    result = {"Predicted House Price" : y_predict.tolist()[0]}
    return jsonify(result)

if __name__ == "__main__":
    app.run(host='0.0.0.0')
